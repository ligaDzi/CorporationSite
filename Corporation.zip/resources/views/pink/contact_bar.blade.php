                        

	<div class="widget-first widget contact-info">
	    <h3>{{ Lang::get('ru.comment') }}</h3>
	    <div class="sidebar-nav">
	        <ul>
	            <li>
	                <i class="icon-map-marker" style="color:#979797;font-size:20pxpx"></i> {{ Lang::get('ru.adress') }}: Москва, Чечёрский проезд 5
	            </li>
	            <li>
	                <i class="icon-info-sign" style="color:#979797;font-size:20pxpx"></i> {{ Lang::get('ru.phone') }}: 4512895656523
	            </li>
	            <li>
	                <i class="icon-print" style="color:#979797;font-size:20pxpx"></i> {{ Lang::get('ru.fax') }}: +38 0505 416 23/
	            </li>
	            <li>
	                <i class="icon-envelope" style="color:#979797;font-size:20pxpx"></i> {{ Lang::get('ru.email') }}: admin@mail.com
	            </li>
	        </ul>
	    </div>
	</div>
	<div class="widget-last widget text-image">
	    <h3>{{ Lang::get('ru.customer_sup') }}</h3>
	    <div class="text-image" style="text-align:left"><img src="{{ asset(config('settings.theme')) }}/images/callus.gif" alt="Customer Support" /></div>
	    <p>Nunc sit amet pretium purus. Pellet netus et malesuada fames ac turpis egestas.entesque habitant morbi tristique senectus </p>
	</div>
