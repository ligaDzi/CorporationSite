<!-- Макет левой колонки для всех страниц -->

    <div class="sidebar group">
        {!! $content_leftBar !!}
    </div>
