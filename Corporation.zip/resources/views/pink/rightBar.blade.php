<!-- Макет правой колонки для всех страниц -->

    <div class="sidebar group">
        {!! $content_rightBar !!}
    </div>
