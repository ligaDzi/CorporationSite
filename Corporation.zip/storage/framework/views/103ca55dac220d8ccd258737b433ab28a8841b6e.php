


<?php $__env->startSection('content'); ?>

    <div id="content-home" class="content group">
    	<div class="hentry group">  
    
    	    <form id="contact-form-contact-us" class="contact-form" method="POST" action="<?php echo e(url('/login')); ?>">
    
    	        <?php echo e(csrf_field()); ?>

    	        <fieldset>
    	            <ul>
    	                <li class="text-field">
    	                    <label for="login">
    	                    <span class="label">Name</span>
    	                    <br />					<span class="sublabel">This is the name</span><br />
    	                    </label>
    	                    <div class="input-prepend"><span class="add-on"><i class="icon-user"></i></span><input type="text" name="login" id="login" class="required" value="" /></div>
    	                     <?php if($errors->has('login')): ?>
    	                        <span class="help-block">
    	                            <strong><?php echo e($errors->first('login')); ?></strong>
    	                        </span>
    	                    <?php endif; ?>
    	                </li>
    
    	                <li class="text-field">
    	                    <label for="password">
    	                    <span class="label">Password</span>
    	                    <br />					<span class="sublabel">This is fiel for password</span><br />
    	                    </label>
    	                    <div class="input-prepend"><span class="add-on"><i class="icon-lock"></i></span><input type="password" name="password"  class="required" value="" /></div>
    	                    <?php if($errors->has('name')): ?>
    	                        <span class="help-block">
    	                            <strong><?php echo e($errors->first('name')); ?></strong>
    	                        </span>
    	                    <?php endif; ?>
    	                </li>
    	                <li class="submit-button">

    	                    <input type="submit" name="yit_sendmail" value="Отправить" class="sendmail alignright" />			
    	                </li>
    	            </ul>
    	        </fieldset>

    	    </form>

    	</div>
    
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make(config('settings.theme').'.layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>