				        
	<div id="content-page" class="content group">
	    <div class="clear"></div>
	    <div class="posts">
	        <div class="group portfolio-post internal-post">
	            <div id="portfolio" class="portfolio-full-description">
	                
                    <?php if($portfolio): ?>

	                    <div class="fulldescription_title gallery-filters">
	                        <h1><?php echo e($portfolio->title); ?></h1>
	                    </div>
                        
	                    <div class="portfolios hentry work group">
	                        <div class="work-thumbnail">
	                            <a class="thumb"><img src="<?php echo e(asset(config('settings.theme'))); ?>/images/projects/<?php echo e($portfolio->img->max); ?>" alt="0081" title="0081" /></a>
	                        </div>
	                        <div class="work-description">
	                            <p><?php echo e($portfolio->text); ?></p>
	                            <div class="clear"></div>
	                            <div class="work-skillsdate">
	                                <p class="skills"><span class="label"><?php echo e(Lang::get('ru.filter')); ?>:</span> <?php echo e($portfolio->filter->title); ?></p>
	                                <p class="workdate"><span class="label"><?php echo e(Lang::get('ru.customer')); ?>:</span> <?php echo e($portfolio->customer); ?></p>

                                    <?php if($portfolio->created_at): ?>
	                                    <p class="workdate"><span class="label"><?php echo e(Lang::get('ru.year')); ?>:</span> <?php echo e($portfolio->created_at->format('Y')); ?></p>
                                    <?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="clear"></div>
	                    </div>
                        
	                    <div class="clear"></div>

                    <?php endif; ?>
	                
                    <?php if($portfolios): ?>

	                <h3><?php echo e(Lang::get('ru.other_portfolio')); ?></h3>  

	                <div class="portfolio-full-description-related-projects">                    
	                    
                        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
	                        <div class="related_project">
	                            <a class="related_proj related_img" href="<?php echo e(route('portfolio.show', ['alias'=> $item->alias])); ?>" title="<?php echo e($item->title); ?>"><img src="<?php echo e(asset(config('settings.theme'))); ?>/images/projects/<?php echo e($item->img->mini); ?>" alt="0061" title="0061" /></a>
	                            <h4><a href="<?php echo e(route('portfolio.show', ['alias'=> $item->alias])); ?>"><?php echo e($item->title); ?></a></h4>
	                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    
	                </div>

                    <?php endif; ?>
	            </div>
	            <div class="clear"></div>
	        </div>
	    </div>
	</div>