<div id="content-page" class="content group">
	<div class="hentry group">
	
	    <h3 class="title_page">Привилегии</h3>
    
	    <form action="<?php echo e(route('admin.permissions.store')); ?>" method="POST">
	    	<?php echo e(csrf_field()); ?>

    
	    	<div class="short-table white">
    
	    		<table style="width:100%">
    
	    			<thead>
    
	    				<th>Привилегии</th>
	    				<?php if(!$roles->isEmpty()): ?>
    
	    					<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    						<th><?php echo e($item->name); ?></th>
	    					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
	    				<?php endif; ?>
    
	    			</thead>
	    			<tbody>
    
	    				<?php if(!$priv->isEmpty()): ?>
    
	    					<?php $__currentLoopData = $priv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    						<tr>
    
	    							<td><?php echo e($val->name); ?></td>
	    								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    									<td>
	    										<?php if($role->hasPermission($val->name)): ?>
	    											<input checked name="<?php echo e($role->id); ?>[]"  type="checkbox" value="<?php echo e($val->id); ?>">
	    										<?php else: ?>
	    											<input name="<?php echo e($role->id); ?>[]"  type="checkbox" value="<?php echo e($val->id); ?>">
	    										<?php endif; ?>	
	    									</td>
	    								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    						</tr>
	    					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
	    				<?php endif; ?>

	    			</tbody>
    
    
	    		</table>
    
    
	    	</div>
    
	    	<input class="btn btn-the-salmon-dance-3" type="submit" value="Обновить" />

    
	    </form>

	
	</div>
</div>