

<?php $__env->startSection('navigation'); ?>

	<?php echo $navigation; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
			        
	<div id="content-index" class="content group">
	    <img class="error-404-image group" src="<?php echo e(asset(config('settings.theme'))); ?>/images/features/404.png" title="Error 404" alt="404" />
	    <div class="error-404-text group">
	        <p>We are sorry but the page you are looking for does not exist.<br />You could <a href="index.html">return to the home page</a> or search using the search box below.</p>
	    </div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

	<?php echo $__env->make(config('settings.theme').'.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>	

<?php echo $__env->make(config('settings.theme').'.layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>