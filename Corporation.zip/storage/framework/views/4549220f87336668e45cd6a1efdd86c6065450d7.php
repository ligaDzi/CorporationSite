<?php if($menu): ?>
	<div class="menu classic">
		
		<?php echo $menu->asUl(['class'=>'menu']); ?>

		
	</div>
<?php endif; ?>