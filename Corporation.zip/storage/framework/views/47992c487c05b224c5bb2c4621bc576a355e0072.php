<?php if($portfolio && count($portfolio) > 0): ?>
						
    <div id="content-home" class="content group">
        <div class="hentry group">
            <div class="section portfolio">
            
	            <!-- Здесь используется переменная из локализациии (resources/lang/(ru или en)/ru.php) -->
                <h3 class="title"><?php echo e(trans('ru.latest_projects')); ?></h3>

                <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($k == 0): ?>
                    
                        <div class="hentry work group portfolio-sticky portfolio-full-description">
                            <div class="work-thumbnail">
                                <a class="thumb"><img src="<?php echo e(asset(config('settings.theme'))); ?>/images/projects/<?php echo e($item->img->max); ?>" alt="0081" title="0081" /></a>
                                <div class="work-overlay">
                                    <h3><a href="<?php echo e(route('portfolio.show', ['alias'=>$item->alias])); ?>"><?php echo e($item->title); ?></a></h3>
                                    <p class="work-overlay-categories"><img src="<?php echo e(asset(config('settings.theme'))); ?>/images/categories.png" alt="Categories" />      in: <a href="#"><?php echo e($item->filter->title); ?></a></p>
                                </div>
                            </div>
                            <div class="work-description">
                                <h2><a href="<?php echo e(route('portfolio.show', ['alias'=>$item->alias])); ?>"><?php echo e($item->title); ?></a></h2>
                                <p class="work-categories">in: <a href="#"><?php echo e($item->filter->title); ?></a></p>

                                <!-- str_limit($item->text, 200) - вывести только 200 символов -->
                                <p><?php echo e(str_limit($item->text, 200)); ?></p>

                                    <a href="<?php echo e(route('portfolio.show', ['alias'=>$item->alias])); ?>" class="read-more">|| Read more</a>
                            </div>
                        </div>

                        <div class="clear"></div>

                        <?php continue; ?>

                    <?php endif; ?>
                    
                    <?php if($k==1): ?>

                        <div class="portfolio-projects">

                    <?php endif; ?>
                

                            <div class="related_project <?php echo e(($k==4) ? ' related_project_last' : ''); ?>">
                                <div class="overlay_a related_img">
                                    <div class="overlay_wrapper">
                                        <img src="<?php echo e(asset(config('settings.theme'))); ?>/images/projects/<?php echo e($item->img->mini); ?>" alt="0061" title="0061" />		    				
                                        <div class="overlay">
                                            <a class="overlay_img" href="<?php echo e(asset(config('settings.theme'))); ?>/images/projects/<?php echo e($item->img->path); ?>" rel="lightbox"     title=""></a>
                                            <a class="overlay_project" href="<?php echo e(route('portfolio.show', ['alias'=>$item->alias])); ?>"></a>
                                            <span class="overlay_title"><?php echo e($item->title); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <h4><a href="<?php echo e(route('portfolio.show', ['alias'=>$item->alias])); ?>"><?php echo e($item->title); ?></a></h4>

                                <!-- str_limit($item->text, 100) - вывести только 100 символов -->
                                <p><?php echo e(str_limit($item->text, 100)); ?></p>

                            </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
            </div>
            <div class="clear"></div>
        </div>
        <!-- START COMMENTS -->
        <div id="comments">
        </div>
        <!-- END COMMENTS -->
    </div>
<?php else: ?>
    <p>Работ нет</p>

<?php endif; ?>