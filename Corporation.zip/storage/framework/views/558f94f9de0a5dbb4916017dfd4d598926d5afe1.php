
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Формирование главных пунктов меню -->
    <li <?php echo e((URL::current() == $item->url()) ? "class=active" : ""); ?>> <!-- Подсветить активный пункт меню -->
        <a href="<?php echo e($item->url()); ?>"><?php echo e($item->title); ?></a>

        <!-- Формирование подпунктов меню -->
        <?php if($item->hasChildren()): ?>
            <ul class="sub-menu">
                <!-- Рекурсия. Здесь вызывается этот же макет, только для дочерних пунктов меню. -->
                <?php echo $__env->make(config('settings.theme').'.customMenuItems',['items'=>$item->children()], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </ul>
        <?php endif; ?>

    </li> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>