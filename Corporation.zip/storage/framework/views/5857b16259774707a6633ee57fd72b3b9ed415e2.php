<div id="content-page" class="content group">
				            <div class="hentry group">
<h3 class="title_page">Пользователи</h3>


<div class="short-table white">
	<table style="width: 100%" cellspacing="0" cellpadding="0">
	<thead>
		<th>ID</th>
		<th>Name</th>
		<th>Email</th>
		<th>Login</th>
		<th>Role</th>
		<th>Удалить</th>
	</thead>
	<?php if($users): ?>
		
		
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($user->id); ?></td>
			<td><?php echo Html::link(route('admin.users.edit',['users' => $user->id]),$user->name); ?></td>
			<td><?php echo e($user->email); ?></td>
			<td><?php echo e($user->login); ?></td>
			<td><?php echo e($user->roles->implode('name', ', ')); ?></td>


			<td>
			<?php echo Form::open(['url' => route('admin.users.destroy',['users'=> $user->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

												    <?php echo e(method_field('DELETE')); ?>

												    <?php echo Form::button('Удалить', ['class' => 'btn btn-french-5','type'=>'submit']); ?>

												<?php echo Form::close(); ?>


			</td>
		</tr>										
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	<?php endif; ?>
	</table>
	</div>
	<?php echo Html::link(route('admin.users.create'),'Добавить  пользователя',['class' => 'btn btn-the-salmon-dance-3']); ?>

	
</div></div>