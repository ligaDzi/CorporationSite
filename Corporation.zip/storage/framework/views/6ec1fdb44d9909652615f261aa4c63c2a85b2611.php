    
    
    <div class="widget-first widget recent-posts">
        <h3><?php echo e(Lang::get('ru.latest_projects')); ?></h3>
        <div class="recent-post group">

            <?php if($portfolio): ?>

                <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <div class="hentry-post group">
                    <div class="thumb-img">
                        <img src="<?php echo e(asset( config('settings.theme'))); ?>/images/projects/<?php echo e($item->img->mini); ?>" style="width:55px;" alt="001" title="001" />
                    </div>
                    <div class="text">
                        <a href="<?php echo e(route('portfolio.show', ['alias'=>$item->alias])); ?>" title="<?php echo e($item->title); ?>" class="title"><?php echo e($item->title); ?></a>
                        <p><?php echo e(str_limit($item->text, 100)); ?> </p>
                        <a class="read-more" href="<?php echo e(route('portfolio.show', ['alias'=>$item->alias])); ?>">&rarr; <?php echo e(Lang::get('ru.read_more')); ?></a>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

        </div>
    </div>
        
    <div class="widget-last widget recent-comments">
        <h3><?php echo e(Lang::get('ru.latest_comments')); ?></h3>
        <div class="recent-post recent-comments group">

         <?php if($comments): ?>

            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <div class="the-post group">
                <div class="avatar">
                <!-- 
                    Граватар это глобальная БД. На их сайте можно добавить свой аватар, который будет привязаг к email.
                    Когда я зарегистрируюсь на каком либо сайте, который поддержует граватар, с этим email, то аватарка подтянится сама.
                    Т.е. одна аватарка на многих сайтах; аватарка привязанная не к сайту, а к email.
                -->
                    <?php $hash =  ( $item->email ? md5($item->email) : md5($item->user->email) ) ?>
                    <img alt="" src="https://www.gravatar.com/avatar/<?php echo e($hash); ?>?d=mm&s=55" class="avatar" />   
                </div>
                <span class="author">
                    <strong>
                        <a href="#"><?php echo e(isset($item->user) ? $item->user->name : $item->name); ?></a>
                    </strong> in
                </span> 
                <a class="title" href="<?php echo e(route('articles.show', ['alias'=>$item->article->alias])); ?>">
                    <?php echo e($item->article->title); ?>

                </a>
                <p class="comment">
                    <?php echo e($item->text); ?> 
                    <a class="goto" href="<?php echo e(route('articles.show', ['alias'=>$item->article->alias])); ?>">&#187;</a>
                </p>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        <?php endif; ?>

        </div>
    </div>
            
    