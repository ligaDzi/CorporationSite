

<?php $__env->startSection('navigation'); ?>

    <?php echo $navigation; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('slider'); ?>

    <?php echo $sliders; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $content; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('bar'); ?>

    <?php echo $rightBar; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

    <?php echo $footer; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('settings.theme').'.layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>