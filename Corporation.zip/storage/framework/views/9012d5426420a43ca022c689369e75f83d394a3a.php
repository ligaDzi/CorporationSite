<li id="li-comment-<?php echo e($data['id']); ?>" class="comment even borGreen">
	<div id="comment-<?php echo e($data['id']); ?>" class="comment-container">
		<div class="comment-author vcard">			                                
			<img alt="" src="https://www.gravatar.com/avatar/<?php echo e($data['hash']); ?>?d=mm&s=75" class="avatar" height="75" width="75" />
		    <cite class="fn"><?php echo e($data['name']); ?></cite>                 
		</div>
						                            
		<div class="comment-meta commentmetadata">
			<div class="intro">
				
			</div>
			<div class="comment-body">
				<p><?php echo e($data['text']); ?></p>
			</div>
		</div>		                           
	</div>
</li>