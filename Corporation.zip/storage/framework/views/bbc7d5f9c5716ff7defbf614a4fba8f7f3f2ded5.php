<!-- Макет левой колонки для всех страниц -->

    <div class="sidebar group">
        <?php echo $content_leftBar; ?>

    </div>
