				        
	<div id="content-page" class="content group">
	    <div class="hentry group">
			<?php if($portfolios): ?>
	    	    <div id="portfolio" class="portfolio-big-image">	            

					<?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    	        	<div class="hentry work group">
	    	        	    <div class="work-thumbnail">
	    	        	        <div class="nozoom">
	    	        	            <img src="<?php echo e(asset(config('settings.theme'))); ?>/images/projects/<?php echo e($portfolio->img->max); ?>" alt="<?php echo e($portfolio->title); ?>" title="<?php echo e($portfolio->title); ?>"/>							
	    	        	            <div class="overlay">
	    	        	                <a class="overlay_img" href="<?php echo e(asset(config('settings.theme'))); ?>/images/projects/<?php echo e($portfolio->img->path); ?>" rel="lightbox"title="<?php echo e($portfolio->title); ?>"></a>
	    	        	                <a class="overlay_project" href="<?php echo e(route('portfolio.show', ['alias'=>$portfolio->alias])); ?>"></a>
	    	        	                <span class="overlay_title"><?php echo e($portfolio->title); ?></span>
	    	        	            </div>
	    	        	        </div>
	    	        	    </div>
	    	        	    <div class="work-description">
	    	        	        <h3><?php echo e($portfolio->title); ?></h3>
	    	        	        <p><?php echo e(str_limit($portfolio->text, 200)); ?></p>
	    	        	        <div class="clear"></div>
	    	        	        <div class="work-skillsdate">

	    	        	            <p class="skills"><span class="label"><?php echo e(Lang::get('ru.filter')); ?>:</span> <?php echo e($portfolio->filter->title); ?></p>
	    	        	            <p class="workdate"><span class="label"><?php echo e(Lang::get('ru.customer')); ?>:</span> <?php echo e($portfolio->customer); ?></p>
													
									<?php if($portfolio->created_at): ?>
										<p class="workdate"><span class="label"><?php echo e(Lang::get('ru.year')); ?>:</span><?php echo e($portfolio->created_at->format('Y')); ?></p>	
									<?php endif; ?>

	    	        	        </div>
	    	        	        <a class="read-more" href="<?php echo e(route('portfolio.show', ['alias'=>$portfolio->alias])); ?>"><?php echo e(Lang::get('ru.read_more')); ?></a>            
	    	        	    </div>
	    	        	    <div class="clear"></div>
	    	        	</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
	    	    </div>
				
				<div class="general-pagination group">
        		    <?php if($portfolios->lastPage() > 1): ?>
						
        		        <?php if($portfolios->currentPage() !== 1): ?>
						
        		            <a href="<?php echo e($portfolios->url($portfolios->currentPage() - 1)); ?>"><?php echo trans('pagination.previous'); ?></a>
						
        		        <?php endif; ?>
						
        		        <?php for($i = 1; $i <= $portfolios->lastPage(); $i++): ?>
						
        		            <?php if($portfolios->currentPage() == $i): ?>
						
        		                <a class="selected disabled"><?php echo e($i); ?></a>
						
        		            <?php else: ?>
						
        		                <a href="<?php echo e($portfolios->url($i)); ?>"><?php echo e($i); ?></a>
						
        		            <?php endif; ?>                   
						
        		        <?php endfor; ?>
						
        		        <?php if($portfolios->currentPage() !== $portfolios->lastPage()): ?>
						
        		            <a href="<?php echo e($portfolios->url($portfolios->currentPage() + 1)); ?>"><?php echo trans('pagination.next'); ?></a>

        		        <?php endif; ?>

        		    <?php endif; ?>
        		</div>

			<?php endif; ?>
	        <div class="clear"></div>
	    </div>
	</div>