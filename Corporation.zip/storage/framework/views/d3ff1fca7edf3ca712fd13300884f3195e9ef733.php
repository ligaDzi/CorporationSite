				        
	<div id="content-page" class="content group">
	    <div class="hentry group">
	        <div id="portfolio" class="portfolio-big-image">
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0061-770x368.jpg" alt="0061" title="0061" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0061.jpg" rel="lightbox" title="Love"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Love</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Love</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="skills"><span class="label">Skills:</span> Illustrator</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0071-770x368.jpg" alt="0071" title="0071" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0071.jpg" rel="lightbox" title="Kineda"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Kineda</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Kineda</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="skills"><span class="label">Skills:</span> Illustrator, InDesign</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0081-770x368.jpg" alt="0081" title="0081" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0081.jpg" rel="lightbox" title="Steep This!"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Steep This!</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Steep This!</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="skills"><span class="label">Skills:</span> Illustrator</p>
	                        <p class="workdate"><span class="label">Customer:</span> Steep This!</p>
	                        <p class="workdate"><span class="label">Year:</span> 2012</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/009-770x368.jpg" alt="009" title="009" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/009.jpg" rel="lightbox" title="Guanacos"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Guanacos</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Guanacos</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="skills"><span class="label">Skills:</span> Photoshop</p>
	                        <p class="workdate"><span class="label">Customer:</span> Guanacos</p>
	                        <p class="workdate"><span class="label">Year:</span> 2011</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0011.jpg" alt="0011" title="0011" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0011.jpg" rel="lightbox" title="Miller Bob"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Miller Bob</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Miller Bob</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="skills"><span class="label">2012:</span> InDesign</p>
	                        <p class="workdate"><span class="label">Customer:</span> Miller Bob</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0027-770x368.jpg" alt="0027" title="0027" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0027.jpg" rel="lightbox" title="VItale Premium"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">VItale Premium</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>VItale Premium</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="workdate"><span class="label">Customer:</span> Vitale Premium</p>
	                        <p class="workdate"><span class="label">Year:</span> 2009</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0034-770x368.jpg" alt="0034" title="0034" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0034.jpg" rel="lightbox" title="Nili Studios"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Nili Studios</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Nili Studios</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="skills"><span class="label">Skills:</span> Illustrator, Photoshop</p>
	                        <p class="workdate"><span class="label">Customer:</span> Nili Yavin</p>
	                        <p class="workdate"><span class="label">Year:</span> 2008</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0043-770x368.jpg" alt="0043" title="0043" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0043.jpg" rel="lightbox" title="Digitpool Medien"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Digitpool Medien</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Digitpool Medien</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <div class="work-skillsdate">
	                        <p class="workdate"><span class="label">Customer:</span> Kai Loh</p>
	                        <p class="workdate"><span class="label">Year:</span> 2012</p>
	                    </div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	            <div class="hentry work group">
	                <div class="work-thumbnail">
	                    <div class="nozoom">
	                        <img src="images/projects/0052-770x368.jpg" alt="0052" title="0052" />							
	                        <div class="overlay">
	                            <a class="overlay_img" href="images/projects/0052.jpg" rel="lightbox" title="Octopus"></a>
	                            <a class="overlay_project" href="project.html"></a>
	                            <span class="overlay_title">Octopus</span>
	                        </div>
	                    </div>
	                </div>
	                <div class="work-description">
	                    <h3>Octopus</h3>
	                    <p>Nullam volutpat, mauris scelerisque iaculis semper, justo odio rutrum urna, at cursus urna nisl et ipsum. Donec dapibus lacus nec sapien faucibus eget suscipit lorem mattis.</p>
	                    <p>Donec non mauris ac nulla consectetur pretium sit amet rhoncus neque. Maecenas aliquet, diam sed [...]
	                    <div class="clear"></div>
	                    <a class="read-more" href="project.html">View Project</a>            
	                </div>
	                <div class="clear"></div>
	            </div>
	            
	        </div>
	        <div class="clear"></div>
	    </div>
	    <!-- START COMMENTS -->
	    <div id="comments">
	    </div>
	    <!-- END COMMENTS -->
	</div>