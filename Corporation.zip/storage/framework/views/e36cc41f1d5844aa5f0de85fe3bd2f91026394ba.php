<!DOCTYPE html>    
    <!-- START HEAD -->
    <head>        
        <meta charset="UTF-8" />

        <title><?php echo e($title); ?></title>
        
        <!-- [favicon] begin -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset(config('settings.theme'))); ?>/images/favicon.ico" />
        
        <!-- CSSs -->
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset(config('settings.theme'))); ?>/css/reset.css" /> <!-- RESET STYLESHEET -->
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset(config('settings.theme'))); ?>/style.css" /> <!-- MAIN THEME STYLESHEET -->
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset(config('settings.theme'))); ?>/css/style-minifield.css" /> <!-- MAIN THEME STYLESHEET -->
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset(config('settings.theme'))); ?>/css/buttons.css" /> <!-- MAIN THEME STYLESHEET -->
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset(config('settings.theme'))); ?>/css/cache-custom.css" /> <!-- MAIN THEME STYLESHEET -->    
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset(config('settings.theme'))); ?>/jquery_ui/jquery-ui.min.css" /> <!-- jQuery UI STYLESHEET -->      
        		
        <!-- FONTs -->
        <link rel="stylesheet" id="google-fonts-css" href="http://fonts.googleapis.com/css?family=Oswald%7CDroid+Sans%7CPlayfair+Display%7COpen+Sans+Condensed%3A300%7CRokkitt%7CShadows+Into+Light%7CAbel%7CDamion%7CMontez&amp;ver=3.4.2" type="text/css" media="all" />
        <link rel='stylesheet' href='<?php echo e(asset(config('settings.theme'))); ?>/css/font-awesome.css' type='text/css' media='all' />
        
        <!-- JAVASCRIPTs -->
        <script type="text/javascript" src="<?php echo e(asset(config('settings.theme'))); ?>/js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo e(asset(config('settings.theme'))); ?>/jquery_ui/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?php echo e(asset(config('settings.theme'))); ?>/js/ckeditor/ckeditor.js"></script>
        <script type="text/javascript" src="<?php echo e(asset(config('settings.theme'))); ?>/js/bootstrap-filestyle.min.js"></script>
        

    </head>
    <!-- END HEAD -->
    
    <!-- START BODY -->
    
    <body class="no_js responsive <?php echo e((Route::currentRouteName() == 'home') ? 'page-template-home-php' : ''); ?> stretched">
        
        <!-- START BG SHADOW -->
        <div class="bg-shadow">
            
            <!-- START WRAPPER -->
            <div id="wrapper" class="group">
                
                <!-- START HEADER -->
                <div id="header" class="group">
                    
                    <div class="group inner">
                        
                        <!-- START LOGO -->
                        <div id="logo" class="group">
                            <a href="<?php echo e(route('home')); ?>" title="Pink Rio"><img src="<?php echo e(asset(config('settings.theme'))); ?>/images/logo.png" title="Pink Rio" alt="Pink Rio" /></a>
                        </div>
                        <!-- END LOGO -->
                        
                        <div id="sidebar-header" class="group">
                            <div class="widget-first widget yit_text_quote">
                                <blockquote class="text-quote-quote">&#8220;The caterpillar does all the work but the butterfly gets all the publicity.&#8221;</blockquote>
                                <cite class="text-quote-author">George Carlin</cite>
                            </div>
                        </div>
                        <div class="clearer"></div>
                        
                        <hr />
                        
                        <!-- START MAIN NAVIGATION -->
							<?php echo $__env->yieldContent('navigation'); ?>
                        <!-- END MAIN NAVIGATION -->
                       
                        <div id="menu-shadow"></div>
                    </div>
                    
                </div>
                <!-- END HEADER -->
				<!-- START PRIMARY -->
				
				<?php if(count($errors) > 0): ?>
				    <div class="box error-box">
				        
				            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                <p><?php echo e($error); ?></p>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				   
				    </div>
				<?php endif; ?>
				
				<?php if(session('status')): ?>
				    <div class="box success-box">
				        <?php echo e(session('status')); ?>

				    </div>
				<?php endif; ?>
				
				<?php if(session('error')): ?>
				    <div class="box error-box">
				        <?php echo e(session('error')); ?>

				    </div>
				<?php endif; ?>
				
				<div id="primary" class="sidebar-<?php echo e(isset($bar) ? $bar : 'no'); ?>">
				    <div class="inner group">
				        <!-- START CONTENT -->
										
						<?php echo $__env->yieldContent('content'); ?>
						
				        <!-- END CONTENT -->
				        <!-- START SIDEBAR -->
						
						<!-- END SIDEBAR -->
				        
						<!-- START EXTRA CONTENT -->
				        <!-- END EXTRA CONTENT -->
				    </div>
				</div>
				<!-- END PRIMARY -->
				
				<!-- START COPYRIGHT -->
                <?php echo $__env->yieldContent('footer'); ?>
                <!-- END COPYRIGHT -->
            </div>
            <!-- END WRAPPER -->
        </div>
        <!-- END BG SHADOW -->        
        
    </body>
    <!-- END BODY -->
</html>