<!-- Макет правой колонки для всех страниц -->

    <div class="sidebar group">
        <?php echo $content_rightBar; ?>

    </div>
