<div id="content-page" class="content group">
	<div class="hentry group">
        <h3 class="title_page">Меню</h3>
        
        <div class="short-table white">
	        <table style="width: 100%" cellspacing="0" cellpadding="0">
	            <thead>

	            	<th>Name</th>
	            	<th>Link</th>

	            	<th>Удалить</th>
	            </thead>
	            <?php if($menus): ?>

	            	<?php echo $__env->make(config('settings.theme').'.admin.custom-menu-items', array('items' => $menus->roots(),'paddingLeft' => ''), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	            <?php endif; ?>
	        </table>
	    </div>
	    <?php echo Html::link(route('admin.menus.create'),'Добавить  пункт',['class' => 'btn btn-the-salmon-dance-3']); ?>

	
    </div>
</div>